﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

internal static class NotebookSetup
{
    const string Title = "보육 업무 수첩";
    const string Commit = "a308fecd109260ebd7c5423a2b14302c2bf3563b";
    const string PackageUrl = "https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/1.0.3537.50/microsoft.web.webview2.1.0.3537.50.nupkg";
    const string PackageHash = "QWnduPtmvtQjH07KtLRQgyYa857P1/cyM8stgy052d53P6WoN4mngtL0bGhs+0DyivdYVirm0GOfaRSM7bcc6w==";
    const string CoreDll = "Microsoft.Web.WebView2.Core.dll";
    const string FormsDll = "Microsoft.Web.WebView2.WinForms.dll";
    const string Loader = "WebView2Loader.dll";
    const string InstallName = "DesktopIcon-1";
    static readonly string[] Files = {"index.html", "icon-192.png", "icon-512.png", "manifest.webmanifest", "sw.js"};
    static readonly string[] Hashes = {"897f92b37b54a212714d43535e62ca4032041210", "1fce559d5da3102f43f9a63c5b328f18a0fcba39", "5ac04aacacb9dfc7f17db225f2fd47baa1c44ed3", "ba0b8f39c9d7835a3751561a88e7078a77c111fe", "68c1e6b27ed1923128e1ee9767abb147f2af7bce"};
    static readonly int[] Sizes = {51944, 555, 2551, 535, 1479};

    [STAThread]
    static int Main(string[] args)
    {
        string stage = null;
        try
        {
            if (args.Length != 1) throw new InvalidOperationException("압축을 모두 푼 뒤 Setup.cmd를 실행해 주세요.");
            string source = Path.Combine(Path.GetFullPath(args[0]), "source");
            if (!File.Exists(Path.Combine(source, "Notebook.cs")) || !File.Exists(Path.Combine(source, "notebook.ico")))
                throw new FileNotFoundException("설치 파일이 일부 없습니다. ZIP 전체를 다시 압축 풀어 주세요.");
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChildcareWorkNotebook");
            string install = Path.Combine(root, InstallName);
            string app = Path.Combine(install, Title + ".exe");
            if (MessageBox.Show("초록색 수첩 아이콘을 쓰는 Windows 앱을 설치할까요?\n\n첫 설치 때 인터넷에 연결되어 있어야 합니다. 이전 보육 업무 수첩은 변경하지 않습니다.", Title, MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return 0;
            if (!File.Exists(app))
            {
                Directory.CreateDirectory(root);
                stage = Path.Combine(root, "DesktopSetup-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(stage);
                string content = Path.Combine(stage, "Content");
                Directory.CreateDirectory(content);
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                using (var net = new TimedClient())
                {
                    net.Headers[HttpRequestHeader.UserAgent] = "ChildcareWorkNotebook-Setup/1.0";
                    for (int i = 0; i < Files.Length; i++)
                    {
                        string oldPath = Path.Combine(Path.Combine(root, Commit.Substring(0, 12)), Files[i]);
                        byte[] data = null;
                        if (File.Exists(oldPath) && new FileInfo(oldPath).Length == Sizes[i]) data = File.ReadAllBytes(oldPath);
                        if (!IsOriginal(data, Sizes[i], Hashes[i]))
                            data = net.DownloadData("https://raw.githubusercontent.com/esranuy-code/childcare-work-notebook/" + Commit + "/" + Files[i]);
                        if (!IsOriginal(data, Sizes[i], Hashes[i])) throw new InvalidDataException("GitHub 원본 확인에 실패했습니다: " + Files[i]);
                        File.WriteAllBytes(Path.Combine(content, Files[i]), data);
                    }
                    byte[] package = net.DownloadData(PackageUrl);
                    using (var sha = SHA512.Create())
                        if (package.Length != 8957746 || Convert.ToBase64String(sha.ComputeHash(package)) != PackageHash)
                            throw new InvalidDataException("Microsoft WebView2 설치 파일의 무결성을 확인하지 못했습니다.");
                    using (var zip = new ZipArchive(new MemoryStream(package, false), ZipArchiveMode.Read))
                    {
                        CopyEntry(zip, "lib/net462/" + CoreDll, Path.Combine(stage, CoreDll));
                        CopyEntry(zip, "lib/net462/" + FormsDll, Path.Combine(stage, FormsDll));
                        CopyEntry(zip, "build/native/x64/" + Loader, Path.Combine(stage, Loader));
                        CopyEntry(zip, "LICENSE.txt", Path.Combine(stage, "Microsoft-WebView2-LICENSE.txt"));
                        CopyEntry(zip, "NOTICE.txt", Path.Combine(stage, "Microsoft-WebView2-NOTICE.txt"));
                    }
                }
                string csc = Path.Combine(RuntimeEnvironment.GetRuntimeDirectory(), "csc.exe");
                string tempApp = Path.Combine(stage, Title + ".exe");
                string appIcon = Path.Combine(stage, "notebook.ico");
                WriteIcon(Path.Combine(content, "icon-512.png"), appIcon);
                var opts = new ProcessStartInfo(csc, "/nologo /target:winexe /platform:x64 /utf8output /optimize+ /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:" + Q(Path.Combine(stage, CoreDll)) + " /r:" + Q(Path.Combine(stage, FormsDll)) + " /win32icon:" + Q(appIcon) + " /out:" + Q(tempApp) + " " + Q(Path.Combine(source, "Notebook.cs")));
                opts.UseShellExecute = false;
                opts.CreateNoWindow = true;
                opts.RedirectStandardOutput = true;
                opts.StandardOutputEncoding = Encoding.UTF8;
                using (var compiler = Process.Start(opts))
                {
                    string log = compiler.StandardOutput.ReadToEnd();
                    compiler.WaitForExit();
                    if (compiler.ExitCode != 0 || !File.Exists(tempApp)) throw new InvalidOperationException("실행 파일을 구성하지 못했습니다.\n" + log);
                }
                Directory.Move(stage, install);
                stage = null;
            }
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string programs = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
            try { MakeShortcut(desktop, app, install); MakeShortcut(programs, app, install); }
            catch (Exception) { MessageBox.Show("앱은 설치했지만 바로가기를 만들 수 없었습니다. 아래 폴더에 실행 파일이 있습니다.\n\n" + install, Title, MessageBoxButtons.OK, MessageBoxIcon.Information); }
            Process.Start(new ProcessStartInfo(app) { WorkingDirectory = install, UseShellExecute = true });
            return 0;
        }
        catch (Exception ex)
        {
            MessageBox.Show("설치를 완료하지 못했습니다. 기존 앱은 그대로 사용할 수 있습니다.\n\n" + ex.Message, Title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return 1;
        }
        finally
        {
            if (stage != null) { try { Directory.Delete(stage, true); } catch (Exception) { } }
        }
    }

    static string Q(string text) { return "\"" + text + "\""; }
    static bool IsOriginal(byte[] data, int size, string expected)
    {
        if (data == null || data.Length != size) return false;
        byte[] header = Encoding.ASCII.GetBytes("blob " + size.ToString(CultureInfo.InvariantCulture) + "\0");
        byte[] blob = new byte[header.Length + data.Length];
        Buffer.BlockCopy(header, 0, blob, 0, header.Length);
        Buffer.BlockCopy(data, 0, blob, header.Length, data.Length);
        using (var sha = SHA1.Create()) return BitConverter.ToString(sha.ComputeHash(blob)).Replace("-", "").Equals(expected, StringComparison.OrdinalIgnoreCase);
    }
    static void CopyEntry(ZipArchive zip, string key, string destination)
    {
        var file = zip.GetEntry(key);
        if (file == null) throw new InvalidDataException("WebView2 구성 파일이 없습니다: " + key);
        using (var source = file.Open()) using (var output = File.Create(destination)) source.CopyTo(output);
    }
    static void WriteIcon(string png, string output)
    {
        int[] sizes = {16, 20, 24, 32, 40, 48, 64, 96, 128, 256};
        var dibs = new byte[sizes.Length][];
        using (var image = new Bitmap(png))
        {
            for (int i = 0; i < sizes.Length; i++)
            {
                int n = sizes[i];
                using (var frame = new Bitmap(n, n, PixelFormat.Format32bppArgb))
                {
                    using (var g = Graphics.FromImage(frame))
                    {
                        g.CompositingMode = CompositingMode.SourceCopy;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                        g.DrawImage(image, new Rectangle(0, 0, n, n), 0, 0, image.Width, image.Height, GraphicsUnit.Pixel);
                    }
                    using (var mem = new MemoryStream())
                    using (var w = new BinaryWriter(mem))
                    {
                        int maskWidth = ((n + 31) / 32) * 4;
                        w.Write(40); w.Write(n); w.Write(n * 2);
                        w.Write((ushort)1); w.Write((ushort)32);
                        w.Write(0); w.Write(n * n * 4); w.Write(0); w.Write(0); w.Write(0); w.Write(0);
                        byte[] mask = new byte[maskWidth * n];
                        for (int y = n - 1; y >= 0; --y)
                            for (int x = 0; x < n; ++x)
                            {
                                Color c = frame.GetPixel(x, y);
                                w.Write(c.B); w.Write(c.G); w.Write(c.R); w.Write(c.A);
                                if (c.A == 0) mask[(n - 1 - y) * maskWidth + x / 8] |= (byte)(1 << (7 - (x % 8)));
                            }
                        w.Write(mask);
                        w.Flush();
                        dibs[i] = mem.ToArray();
                    }
                }
            }
        }
        using (var w = new BinaryWriter(File.Create(output)))
        {
            w.Write((ushort)0); w.Write((ushort)1); w.Write((ushort)sizes.Length);
            int offset = 6 + 16 * sizes.Length;
            for (int i = 0; i < sizes.Length; ++i)
            {
                byte dim = (byte)(sizes[i] % 256);
                w.Write(dim); w.Write(dim); w.Write((byte)0); w.Write((byte)0);
                w.Write((ushort)1); w.Write((ushort)32);
                w.Write(dibs[i].Length); w.Write(offset);
                offset += dibs[i].Length;
            }
            foreach (var dib in dibs) w.Write(dib);
        }
    }
    static void MakeShortcut(string folder, string app, string install)
    {
        if (String.IsNullOrEmpty(folder) || !Directory.Exists(folder)) return;
        dynamic shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell", true));
        dynamic link = shell.CreateShortcut(Path.Combine(folder, Title + " (초록 아이콘).lnk"));
        link.TargetPath = app;
        link.WorkingDirectory = install;
        link.Description = "보육 업무 수첩 - Windows 앱";
        link.IconLocation = app + ",0";
        link.Save();
    }
    sealed class TimedClient : WebClient
    {
        protected override WebRequest GetWebRequest(Uri uri)
        {
            var request = (HttpWebRequest)base.GetWebRequest(uri);
            request.Timeout = 45000;
            request.ReadWriteTimeout = 45000;
            return request;
        }
    }
}
