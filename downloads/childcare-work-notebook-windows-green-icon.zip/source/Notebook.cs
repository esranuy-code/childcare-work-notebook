﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

[assembly: AssemblyTitle("보육 업무 수첩")]
[assembly: AssemblyProduct("보육 업무 수첩")]
[assembly: AssemblyVersion("1.1.0.0")]

internal static class Notebook
{
    public const string Title = "보육 업무 수첩";
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try { Application.Run(new NotebookWindow()); }
        catch (Exception ex)
        {
            MessageBox.Show("업무 수첩을 열지 못했습니다.\n\n" + ex.Message, Title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
internal sealed class NotebookWindow : Form
{
    readonly WebView2 view;
    readonly Label loading;
    readonly Icon icon;
    public NotebookWindow()
    {
        Text = Notebook.Title;
        icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        Icon = icon;
        ShowIcon = true;
        ShowInTaskbar = true;
        WindowState = FormWindowState.Normal;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1120, 760);
        MinimumSize = new Size(420, 320);
        view = new WebView2 { Dock = DockStyle.Fill, Visible = false, DefaultBackgroundColor = Color.White };
        loading = new Label { Text = "보육 업무 수첩을 여는 중입니다.", TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill };
        Controls.Add(view);
        Controls.Add(loading);
        Shown += OpenNotebook;
    }
    async void OpenNotebook(object sender, EventArgs args)
    {
        Shown -= OpenNotebook;
        try
        {
            string pagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Content", "index.html");
            if (!File.Exists(pagePath)) throw new FileNotFoundException("업무 수첩 파일을 찾을 수 없습니다. 설치 폴더를 확인해 주세요.");
            var page = new Uri(pagePath);
            string profile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChildcareWorkNotebook", "DesktopIcon-Profile");
            var environment = await CoreWebView2Environment.CreateAsync(null, profile, null);
            if (IsDisposed || Disposing) return;
            await view.EnsureCoreWebView2Async(environment);
            if (IsDisposed || Disposing) return;
            view.CoreWebView2.Settings.IsWebMessageEnabled = false;
            view.CoreWebView2.Settings.AreHostObjectsAllowed = false;
            view.CoreWebView2.NavigationStarting += delegate(object o, CoreWebView2NavigationStartingEventArgs e)
            {
                Uri requested;
                e.Cancel = !Uri.TryCreate(e.Uri, UriKind.Absolute, out requested) || !requested.IsFile ||
                    !String.Equals(requested.GetLeftPart(UriPartial.Path), page.GetLeftPart(UriPartial.Path), StringComparison.OrdinalIgnoreCase);
            };
            view.CoreWebView2.NewWindowRequested += delegate(object o, CoreWebView2NewWindowRequestedEventArgs e) { e.Handled = true; };
            view.CoreWebView2.NavigationCompleted += delegate(object o, CoreWebView2NavigationCompletedEventArgs e)
            {
                if (e.IsSuccess) { loading.Visible = false; view.Visible = true; }
                else if (!view.Visible) loading.Text = "업무 수첩을 불러오지 못했습니다. (" + e.WebErrorStatus.ToString() + ")";
            };
            view.Source = page;
        }
        catch (WebView2RuntimeNotFoundException)
        {
            if (IsDisposed || Disposing) return;
            loading.Text = "이 PC에 Microsoft Edge WebView2 Runtime이 필요합니다.\r\n사용 안내.txt의 Microsoft 공식 링크를 참고해 주세요.";
        }
        catch (Exception ex)
        {
            if (IsDisposed || Disposing) return;
            loading.Text = "업무 수첩을 열지 못했습니다.\r\n" + ex.Message;
        }
    }
    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (disposing && icon != null) icon.Dispose();
    }
}
