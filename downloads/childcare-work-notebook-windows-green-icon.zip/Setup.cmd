@echo off
setlocal DisableDelayedExpansion
set "FX=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FX%\csc.exe" goto :noCompiler
if not exist "%~dp0source\Setup.cs" goto :noSource
set "WORK=%TEMP%\ChildcareNotebookSetup-%RANDOM%-%RANDOM%"
md "%WORK%" 2>nul || goto :noTemp
"%FX%\csc.exe" /nologo /target:winexe /platform:x64 /optimize+ /utf8output /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.IO.Compression.dll /r:Microsoft.CSharp.dll /win32icon:"%~dp0source\notebook.ico" /out:"%WORK%\NotebookSetup.exe" "%~dp0source\Setup.cs"
if errorlevel 1 goto :compileFailed
start "" /wait "%WORK%\NotebookSetup.exe" "%~dp0."
set "RESULT=%ERRORLEVEL%"
del /q "%WORK%\NotebookSetup.exe" 2>nul
rd "%WORK%" 2>nul
exit /b %RESULT%
:compileFailed
rd "%WORK%" 2>nul
 echo Setup could not start. Please contact your IT administrator.
pause
exit /b 1
:noCompiler
 echo Windows x64 with .NET Framework 4.8 is required.
pause
exit /b 1
:noSource
 echo Extract the entire ZIP before running Setup.cmd.
pause
exit /b 1
:noTemp
 echo Could not create a temporary setup folder.
pause
exit /b 1
